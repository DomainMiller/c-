#include<stdio.h>
void main()
{
	char i1, i2;
    i1='A';i2='B';
    printf("%d,%d\n", i1, i2);
    printf("%c,%c\n", i1, i2 );
}