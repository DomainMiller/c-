#include<stdio.h>
void main()
{
	int i1, i2;
    i1='A';i2='B';
    printf("%d,%d\n", i1, i2);
}
